<!-- <amp-auto-ads type="adsense" data-ad-client="ca-pub-3225747166990008"></amp-auto-ads>
<?php
$iklan = array(
	array(
		"http://ho.lazada.co.id/SHdEZh",
		"https://media.go2speed.org/brand/files/lazada/9190/ID_Goldwatchesramadhan_500x500.jpg" 
		),
	array(
		"http://ho.lazada.co.id/SHdETV", 
		"https://media.go2speed.org/brand/files/lazada/9195/ID_PuasaleTeasing_500x500.jpg"
		),
	array(
		"http://ho.lazada.co.id/SHdEZo", 
		"https://media.go2speed.org/brand/files/lazada/9108/ID_CuciGudangEL_500x500.jpg"
		)

	);

$ran = $iklan;
$raniklan = $ran[array_rand($ran, 1)];
?>

<a href="<?php echo $raniklan[0]; ?>" target="_blank"><img src="<?php echo $raniklan[1]; ?>" width="100%"></a> -->
<label>
Please Like Our New Fans Page</label>
<div class="fb-page" data-href="https://www.facebook.com/nontonanime21.live/" data-tabs="timeline" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/nontonanime21.live/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/nontonanime21.live/">Nontonanime21.live</a></blockquote></div>
<br><br>
<script type="text/javascript">
var ad_idzone = "3110736",
	 ad_width = "100%";
</script>
<script type="text/javascript" src="https://ads.exdynsrv.com/ads.js"></script>
<noscript><a href="https://main.exdynsrv.com/img-click.php?idzone=3110736" style="width: 100%;" target="_blank"><img src="https://syndication.exdynsrv.com/ads-iframe-display.php?idzone=3110736&output=img&type=300x250"  width="100%"></a></noscript>