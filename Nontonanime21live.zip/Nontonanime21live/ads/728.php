<script type="text/javascript">
var ad_idzone = "3103182",
	 ad_width = "728",
	 ad_height = "90";
</script>
<script type="text/javascript" src="https://ads.exdynsrv.com/ads.js"></script>
<noscript><a href="https://main.exdynsrv.com/img-click.php?idzone=3103182" target="_blank"><img src="https://syndication.exdynsrv.com/ads-iframe-display.php?idzone=3103182&output=img&type=728x90" width="728" height="90"></a></noscript>