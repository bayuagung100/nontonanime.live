<script type="text/javascript">
	protected_links = "<?php echo $prodomain; ?>"; 
	auto_safelink();
</script>
</div>
<div id="footer">
	<div class="container">
		<a href="/" class="logo-footer">
			<img src="/nonton-anime-21.png">
		</a>
		<div class="key_footer hidden-xs" style="margin-top:1em"> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="nonton Anime">Nonton Anime</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="nonton Anime">Nonton Anime Terbaru dan Terlengkap</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Anime Indo<">Anime Indo</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Nonton Anime Subtitle Indonesia">Nonton Anime Subtitle Indonesia</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Download Anime">Download Anime</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Situs Anime online gratis">Situs Anime online gratis</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Download Anime Subtitle Indonesia">Download Anime Subtitle Indonesia</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Animeindoweb">Animeindoweb</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Anime Terbaru">Film Anime Terbaru <?php echo date(Y); ?></a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Nonton Anime Indo">Nonton Anime Indo terbaru</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Nonton anime gratis">Nonton anime samehadaku gratis</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="movieu">Movieu Online</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Layarkacaxxi">Layarkacaxxi</a></h3> <h5><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Layarkacaxxi">Streaming anime Subtitle Indonesia</a></h5> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Nonton Naruto Subtitle Indonesia">Nonton Naruto Subtitle Indonesia</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Nonton Anime Online">Nonton Anime Online</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Nonton Anime Favorit">Nonton Anime Favorit</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Streaming Anime">Streaming Anime</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Streaming Anime Subtitle indonesia">Streaming Anime Subtitle indonesia</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Nonton Streaming Anime">Nonton Streaming Anime</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="LK21 Cinema indonesia">Layarkaca21 Cinema indonesia</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Nonton Film Anime">Nonton Film Anime</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Nonton Film Anime Subtitle Indonesia">Nonton Film Anime Subtitle Indonesia</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Nonton Anime Web">Nonton Anime Web</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Video Naruto">Video Naruto</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>/" title="Nonton Anime Naruto">Nonton Anime Naruto</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Download Layarkaca21">Download Film</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="LK21 Download">LK21 Film Download</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Animeindo">Animeindo</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Situs Nonton Anime">Situs Nonton Anime Subtitle Indonesia</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Anime terbaru 2017">Anime Subtitle Indonesia terbaru 2017</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="nonton naruto Subtitle Indonesia">Nonton Naruto Subtitle Indonesia</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="nonton naruto shippuden">Nonton Naruto Shippuden</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="nonton film boruto">Nonton Film Boruto</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Nonton Boruto Full Episode">Nonton Boruto Full Episode</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Nonton Anime One Piece">Nonton Anime One Piece</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Nonton Anime action gratis">Nonton Anime action gratis</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Nonton Anime Subtitle Indonesia Terlengkap">Nonton Anime Subtitle Indonesia Terlengkap</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="nonton anime Subtitle Indonesia one punch man">Nonton Anime Subtitle Indonesia One Punch Man</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Nonton Anime Subtitle Indonesia Dragon Ball">nonton anime Subtitle Indonesia dragon ball super</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Layarkaca21">Layarkaca21</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="icinema3satu">icinema3satu</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Anime Spring Subtitle Indonesia">Anime Spring Subtitle Indonesia</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Daftar Anime Samehadaku">Daftar Anime Samehadaku</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Samehadaku Net">Samehadaku Net</a></h3> <h3><a class="label" href="<?php echo $_SERVER['REQUEST_URI']; ?>" title="Anime Subtitle Indonesia Samehadaku">Anime Subtitle Indonesia Samehadaku</a></h3></div>
		<center style="color: #555;" ><h2 class="p" style="color: #555;">Nonton anime subtitle indonesia</h2> terbaru <?php echo date('Y'); ?> dan terlengkap - <a href="./" style="color: #555;" title="Nonton Anime 21">Nonton Animen 21</a></center>
		<div class="menu-bottom" id="main-menu">
			<ul id="menu-menu" class="menu">
				<li id="menu-item-9416" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-9416">
					<a href="/">Home</a>
				</li>
				<li id="menu-item-9478" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-9478">
					<a href="/genres">Genre</a>
				</li>
				<li id="menu-item-9478" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-9478">
					<a href="/anime-list">List Anime</a>
				</li>
				<li id="menu-item-9478" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-9478">
					<a href="/movie-list">Movie</a>
				</li>
				<li id="menu-item-9687" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-9687">
					<a href="/popular-series">Popular Series</a>
				</li>
				<li id="menu-item-9803" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-9803">
					<a href="/anime-ongoing">Anime Ongoing</a>
				</li>
			</ul>
			<ul style="float: right;" id="menu-menu" class="menu">
				<li style="float: right;" id="menu-item-9803" class=" pull-right menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-9803">
					<a href="/anime-ongoing">DMCA</a>
				</li>
				<li style="float: right;" id="menu-item-9803" class=" pull-right menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-9803">
					<a href="/anime-ongoing">Privasi</a>
				</li>
				<li style="float: right;" id="menu-item-9803" class=" pull-right menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-9803">
					<a href="/anime-ongoing">Bantuan</a>
				</li>
			</ul>
		</div>
	</div>

</div>
<a href="https://tools.seoservices.com/keyword-density-checker">Keyword density tool</a>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.1.min.js" async>
</script>
<script src="https://unpkg.com/flickity@2.0/dist/flickity.pkgd.min.js" async>
</script> <script type='text/javascript' src='js/wp-embed.min.js?ver=4.8.1' async>
</script>
<script src="//pop-under.xml.adx1.com/js/popunder.js?publisher_id=67484&site_id=36122&iab_category=0"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous" async></script>

<script src="/js/anime.js" async></script>

<script type='text/javascript' async>/*<![CDATA[*/$(document).ready(function(){$("#shadow").css("height",$(document).height()).hide();$(".lightSwitcher").click(function(){$("#shadow").toggle();if($("#shadow").is(":hidden")){$(this).html("Cinema mode OFF").removeClass("turnedOff")}else{$(this).html("Cinema mode ON").addClass("turnedOff")}})});/*]]>*/</script>

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.1';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<?php include 'histat.php'; ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-119582388-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-119582388-1');
</script>
</body>
</html>