<?php
$iklan = array(
	array(
		"http://ho.lazada.co.id/SHdEZh",
		"https://media.go2speed.org/brand/files/lazada/9190/ID_Goldwatchesramadhan_500x500.jpg" 
		),
	array(
		"http://ho.lazada.co.id/SHdETV", 
		"https://media.go2speed.org/brand/files/lazada/9195/ID_PuasaleTeasing_500x500.jpg"
		),
	array(
		"http://ho.lazada.co.id/SHdEZo", 
		"https://media.go2speed.org/brand/files/lazada/9108/ID_CuciGudangEL_500x500.jpg"
		)

	);

$ran = $iklan;
$raniklan = $ran[array_rand($ran, 1)];
?>

<a href="<?php echo $raniklan[0]; ?>" target="_blank"><img src="<?php echo $raniklan[1]; ?>" width="100%"></a>