
<!Doctype html>
<html xmlns="https://www.w3.org/1999/xhtml" lang="id">
<link rel="icon" type="image/png" href="https://www1.nontonanime21.live/One-Piece-anime.ico">
<meta name="msvalidate.01" content="E8A7015443ECC877AC07A51F7A77ED39" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="googlebot" content="index,follow" />
<meta name="msvalidate.01" content="E8A7015443ECC877AC07A51F7A77ED39" />
<?php 
$actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
if (strpos($actual_link, 'nontonanime21.live/nonton/') or strpos($actual_link, 'nontonanime21.live/anime/')) { ?>
	<title>Nonton Anime <?php echo str_ireplace('-', ' ', $_GET['video']); ?> Subtitle Indonesia - NontonAnime21</title>
	<?php }else{ ?>
	<title>Nonton Anime Subtitle Indonesia Terbaru <?php echo date('Y'); ?> dan Terlengkap full episode - NontonAnime21</title>
	<?php } ?>

	<link href="//fonts.googleapis.com/css?family=Droid Sans:regular,700&subset=latin" rel="stylesheet" type="text/css"/>
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,400i,600,600i,700,700i" rel="stylesheet">
	<link href="/style.min.css" rel="stylesheet" type="text/css" />

	<link rel="stylesheet" href="https://unpkg.com/flickity@2.0/dist/flickity.css" media="screen">
	<?php if (strpos($actual_link, 'nontonanime21.live/nonton/')) { ?>
	<link rel="canonical" href="<?php echo $actual_link; ?>">
	<?php }else{ ?>
	<link rel="canonical" href="https://www1.nontonanime21.live">
	<?php } ?>
	<meta name="Author" content="Nonton Anime 21">

	<?php if (strpos($actual_link, 'nontonanime21.live/nonton/')) { 
	$descrrr = potong($url2, '<div class="infobox">', '<div class="inr">');
	$titleee = potong($descrrr, '<h3>', '</h3>');
	$kettt = potong($descrrr, '<div class="seno">', '</div>'); 
	$kettt = str_replace("<p>","",$kettt);
	$kettt = str_replace("</p>","",$kettt);
	$kettt = str_replace("&#8230;","",$kettt);
	$kettt = trim(preg_replace('/\s+/', ' ', $kettt)); ?>
	<meta name="description" content="<?php echo $titleee; ?> - <?php echo $kettt; ?> - Nonton Anime <?php echo $titleee; ?> Subtitle Indonesia"/>
<?php }else{ ?>
	<meta name="description" content="NontonAnime21 - Web Nonton Anime Subtitle Indonesia Terbaru <?php echo date('Y'); ?> dan Terlengkap full episode. Streaming Anime Online Terlengkap. Nonton Online Streaming Film Anime terbaik terlengkap. Download Film Anime Terbaru. Gratis."/>
	<?php } ?>
	<meta name="Keywords" content="<?php $titlee = str_ireplace('-', ' ', $_GET['video']); echo str_ireplace('.html', '', $titlee); ?>, Nonton Anime 21, NontonAnime21, Nonton Anime terbaru dan terlengkap, Nonton Anime, Anime Indo, Nonton Anime Subtitle Indonesia, Download Anime, Situs Anime online gratis, Download Anime Subtitle Indonesia, Animeindoweb, Film Anime Terbaru 2018, Nonton Anime Indo terbaru, Nonton anime samehadaku gratis, Movieu Online, Layarkacaxxi, Streaming anime Subtitle Indonesia, Nonton Naruto Subtitle Indonesia, Nonton Anime Online, Nonton Anime Favorit, Streaming Anime, Streaming Anime Subtitle indonesia, Nonton Streaming Anime, Layarkaca21 Cinema indonesia, Nonton Film Anime, Nonton Film Anime Subtitle Indonesia, Nonton Anime Web, Video Naruto, Nonton Anime Naruto, Download Film, LK21 Film Download, Animeindo, Situs Nonton Anime Subtitle Indonesia, Anime Subtitle Indonesia terbaru 2017, Nonton Naruto Subtitle Indonesia, Nonton Naruto Shippuden, Nonton Film Boruto, Nonton Boruto Full Episode, Nonton Anime One Piece, Nonton Anime action gratis, Nonton Anime Subtitle Indonesia Terlengkap, Nonton Anime Subtitle Indonesia One Punch Man, nonton anime Subtitle Indonesia dragon ball super, Layarkaca21, icinema3satu, Anime Spring Subtitle Indonesia, Daftar Anime Samehadaku, Samehadaku Net, Anime Subtitle Indonesia Samehadaku">
	<meta property="og:locale" content="id_ID" />
	<meta property="og:url" content="https://www1.nontonanime21.live" />
	
	<?php if (strpos($actual_link, 'nontonanime21.live/nonton/')) { 
	$descrrr = potong($url2, '<div class="infobox">', '<div class="inr">');
	$titleee = potong($descrrr, '<h3>', '</h3>'); ?>
	<meta property="og:title" content="Nonton Anime <?php echo $titleee; ?> Subtitle Indonesia - Nontonanime21" />
	<?php }else{ ?>
	<meta property="og:title" content="Nonton Anime Subtitle Indonesia Terbaru <?php echo date('Y'); ?> dan Terlengkap full episode" />
	<?php } ?>
	
	<?php if (strpos($actual_link, 'nontonanime21.live/nonton/')) { 
	$descrrr = potong($url2, '<div class="infobox">', '<div class="inr">');
	$titleee = potong($descrrr, '<h3>', '</h3>');
	$kettt = potong($descrrr, '<div class="seno">', '</div>'); 
	$kettt = str_replace("<p>","",$kettt);
	$kettt = str_replace("</p>","",$kettt);
	$kettt = str_replace("&#8230;","",$kettt);
	$kettt = trim(preg_replace('/\s+/', ' ', $kettt)); ?>
	<meta property="og:description" content="<?php echo $titleee; ?> - <?php echo $kettt; ?> -  - Nonton Anime <?php echo $titleee; ?> Subtitle Indonesia" />
<?php }else{ ?>
	<meta property="og:description" content="NontonAnime21 - Web Nonton Anime Subtitle Indonesia Terbaru <?php echo date('Y'); ?> dan Terlengkap full episode. Streaming Anime Online Terlengkap. Nonton Online Streaming Film Anime terbaik terlengkap. Download Film Anime Terbaru. Gratis." />
	<?php } ?>
	<meta property="og:image" content="<?php echo $thumb; ?>" />
	<meta property="og:site_name" content="Nonton Anime 21" />
	<meta property="og:type" content="Object" />
	<script type="application/ld+json">
		{
			"@context": "https://schema.org",
			"@type": "WebSite",
			"url": "https://www1.nontonanime21.live",
			"name": "NontonAnime21",
			"alternateName": "Nonton Anime 21",
			"potentialAction": 
			{
				"@type": "SearchAction",
				"target": "https://www1.nontonanime21.live/search/{q}",
				"query-input": "required name=q"
			}
		}
	</script>

	<!-- / Yoast SEO plugin. -->
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

	<!-- Latest compiled and minified JavaScript -->

	<meta name="generator" content="Nonton Anime 21" />
	<!-- empty --> <!-- empty -->
	<?php include 'ads/popup.php'; ?>
</head>
<body>
	<!-- empty -->
	<div id='shadow'>
	</div>
	<nav class="navbar navbar-default">
		<div class="container">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="/" title="Nonton Anime 21">
					<img src="/nonton-anime-21.png" alt="Nonton Anime 21" title="Nonton Anime 21">
				</a>
			</div>

			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav">
					<li>
						<a href="/" title="Nonton Anime 21">Home</a>
					</li>
					<li>
						<a href="/genres" title="Genre Anime">Genre</a>
					</li>
					<li>
						<h4 class="menu-h4"><a href="/anime-list" title="List Anime">List Anime</a></h4>
					</li>
					<li>
						<a href="/movie-list" title="Movie Anime">Movie</a>
					</li>
					<li>
						<h4 class="menu-h4"><a href="/popular-series" title="Populer Series Anime">Popular Series</a></h4>
					</li>
					<li>
						<h4 class="menu-h4"><a href="/anime-ongoing" title="Anime Ongoing">Anime Ongoing</a></h4>
					</li>
				</ul>
				<form method="get" id="searchform" action="/search.php">
					<input id="s" class="search-live" type="text" placeholder="Cari anime disini..." name="q"/>
					<button class="btn btn-danger" type="submit"><i class="fa fa-search"></i></button>
				</form>
			</div><!-- /.navbar-collapse -->
		</div><!-- /.container-fluid -->
	</nav>



	<div class="container">
		<div class="row">
			<div class="col-md-12" style="float: inherit;">
				<div class="h1anime">
					<h1>Nonton Anime</h1>
				</div>
				<div class="genrehome">
					<a class="col-md-2" href="/genre/action" title="action">Action</a>
					<a class="col-md-2" href="/genre/adventure" title="adventure">Adventure</a>
					<a class="col-md-2" href="/genre/based-on-a-comic" title="based-on-a-comic">Based on a Comic</a>
					<a class="col-md-2" href="/genre/card-game" title="card-game">Card Game</a>
					<a class="col-md-2" href="/genre/cars" title="cars">Cars</a>
					<a class="col-md-2" href="/genre/comedy" title="comedy">Comedy</a>
					<a class="col-md-2" href="/genre/crime" title="crime">Crime</a>
					<a class="col-md-2" href="/genre/dementia" title="dementia">Dementia</a>
					<a class="col-md-2" href="/genre/demons" title="demons">Demons</a>
					<a class="col-md-2" href="/genre/drama" title="drama">Drama</a>
					<a class="col-md-2" href="/genre/ecchi" title="ecchi">Ecchi</a>
					<a class="col-md-2" href="/genre/family" title="family">Family</a>
					<a class="col-md-2" href="/genre/fantasy" title="fantasy">Fantasy</a>
					<a class="col-md-2" href="/genre/friendship" title="friendship">Friendship</a>
					<a class="col-md-2" href="/genre/game" title="game">Game</a>
					<a class="col-md-2" href="/genre/genres-action" title="genres-action">Genres: Action</a>
					<a class="col-md-2" href="/genre/harem" title="harem">Harem</a>
					<a class="col-md-2" href="/genre/historical" title="historical">All Genre</a>
				</div>
			</div>