<?php
include 'config/func.php';
if($_GET['page']) {
	$page = $_GET['page'];
	$url = ''.$spath.'/page/'.$page.'/';
} else {
	$url = ''.$spath.'';
}

$hot = strstr(grab($url), '<div class="wrap mobilewrap">');
$thumb = potong($hot, 'src="', '"'); 
include 'head.php';

echo '<div class="col-md-12">
<div id="content">
	<div class="stl"><div class="icon-list"><i class="fa fa-fire"></i></div> <h2 class="h2-category">Hot Update Minggu Ini</h2></div>
	<div class="carousel" height="225px" data-flickity=\'{ "autoPlay": true,"wrapAround": true }\'>';
		$urlhot = explode('<div class="node">', $hot);
// menghitung banyaknya data yang terdapat pada array
		$count = count($urlhot);
		$count = $count-1;

// mengulang sebanyak data yang terdapat pada array
// disini saya menggunakan for
		for($i=1; $i<=7; $i++) {
			$title = potong($urlhot[$i], '<div class="title">', '</div>');
			$id2 = potong($urlhot[$i], 'href="', '"');
			$id2 =  str_ireplace(''.$spath.'', '/nonton', $id2);
			$cover = potong($urlhot[$i], 'src="', '"');
			$path=$cover;
			$type1 = pathinfo($path, PATHINFO_EXTENSION);
			$data = file_get_contents($path);
			$base64 = 'data:image/' . $type1 . ';base64,' . base64_encode($data);
			$stat = potong($urlhot[$i], '<span class="sub">', '</span>');
			$episode = potong($urlhot[$i], '<div class="episode">', '</div>');
//$judul2 = potong($urlxxx[$i], '<h2 class="title-main-obj ellipsis-2">', '</h2>');
//$arties = potong($urlxxx[$i], '<h4 class="title-sub ellipsis-2">', '</h4>');

			echo '
			<div class="col-md-2 col-xs-6">
				<div class="carousel-cell">
					<a rel="789" href="'.$id2.'" title="'.$title.'">
						<img width="200" height="300" src="'.$base64.'" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="'.$title.'" />
						<div class="ep">'.$episode.'</div>
						<div class="ctl">
							<h2>'.$title.'</h2>
						</div>
					</a>
				</div>
			</div>';
		}
		echo '</div>
		<!--end Hot Update Minggu Ini -->
		<div class="row">
			<div class="col-md-8">
				<center>';
					include 'ads/728.php';
					echo '</center>
					<div class="terbaru">
						<div class="stl">
							<div class="icon-list">
								<i class="fa fa-fire"></i>
							</div>
							<h2 class="h2-category">Episode Terbaru</h2>
						</div>
						<div class="episodes row">';

							$urlx = strstr(grab($url), '<div id="sct_content" class="fl mobilewrap">');
							$paging = potong($urlx, '<div class="pagination">', '</div>');
							$paging =  str_ireplace(''.$spath.'', '', $paging);

//$urlxx = strstr(grab($url), '<div id="episodes">');

							$urlxxx = explode('<div class="node">', $urlx);
// menghitung banyaknya data yang terdapat pada array
							$count = count($urlxxx);
							$count = $count-1;

// mengulang sebanyak data yang terdapat pada array
// disini saya menggunakan for
							for($i=1; $i<=$count; $i++) {
								$title = potong($urlxxx[$i], '<div class="title">', '</div>');
								$id2 = potong($urlxxx[$i], 'href="', '"');
								$id2 =  str_ireplace(''.$spath.'', '/nonton', $id2);
								$cover = potong($urlxxx[$i], 'src="', '"');
								$path=$cover;
								$type1 = pathinfo($path, PATHINFO_EXTENSION);
								$data = file_get_contents($path);
								$base64 = 'data:image/' . $type1 . ';base64,' . base64_encode($data);
								$stat = potong($urlxxx[$i], '<span class="sub">', '</span>');
								$episode = potong($urlxxx[$i], '<div class="episode">', '</div>');
//$judul2 = potong($urlxxx[$i], '<h2 class="title-main-obj ellipsis-2">', '</h2>');
//$arties = potong($urlxxx[$i], '<h4 class="title-sub ellipsis-2">', '</h4>');

								?>    
								<div class="col-md-3 col-xs-6">
									<div class="box">
										<div class="eps">
											<a href="<?php echo $id2; ?>" title="<?php echo $title; ?>">
												<img width="200" height="300" src="<?php echo $base64; ?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" title="<?php echo $title; ?>" alt="<?php echo $title; ?>" />
												<div class="ep"><?php echo $episode; ?></div>
												<div class="ctl">
													<h2><?php echo $title; ?></h2>
												</div>

											</a>
										</div>
									</div>
								</div>

								<?php
							}
							?>
						</div>
						<div class="pagination">
							<?php echo $paging; ?>
						</div>
					</div>
				</div>
				<!--batas content index -->
				<?php include 'side.php'; ?>
			</div>
		</div>
		<?php include 'foot.php'; ?>